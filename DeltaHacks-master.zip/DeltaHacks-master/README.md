# YARP 
### Google Extension to remove any unnessecary Google searches tabs opened

# Idea
Our Idea was to create a google extension that creates a simple and clean organization to the long list of tabs you have open. Our idea was to group tabs by domains first so that it can be easily accessible to users without trying to look through huge list of tabs

## Complete
We couldnt get our initial idea working so we decided that we dial it back down and just delete all you tabs that are google searches. I personally open lot of google webpage with searches when i am doing research and these unused tabs are never used again so our extension deletes that for you. 

## Installation and Usage
Our chrome extension is not on Google Store so you will have to download the foler, then go to your chrome browswer and then moretools>extensions, then enable developer mode and then click load unpacked extensions where it will ask u to choose a folder and so select our folder you downloaded and then there will appear a little green button on ur tabs when u successfully installed the extension. 
